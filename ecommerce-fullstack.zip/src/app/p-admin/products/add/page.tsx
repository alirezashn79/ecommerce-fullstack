import AddProduct from "components/templates/p-admin/products/addProduct";

export default function page() {
  return <AddProduct />;
}
