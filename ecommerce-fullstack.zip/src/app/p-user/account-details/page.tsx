import AccountDetails from "components/templates/p-user/details/account-details";

const page = () => {
  return <AccountDetails />;
};

export default page;
