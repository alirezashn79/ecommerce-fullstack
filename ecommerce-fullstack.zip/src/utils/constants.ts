export const authTypes = {
  LOGIN: "login",
  REGISTER: "register",
};
